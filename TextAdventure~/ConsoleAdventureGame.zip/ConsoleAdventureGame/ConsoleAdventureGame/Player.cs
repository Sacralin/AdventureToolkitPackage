﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAdventureGame
{
    internal class Player
    {
        public string name = "Player";
        public int locationX = 0;
        public int locationY = 2;

        public Player()
        {

        }
    }
}
